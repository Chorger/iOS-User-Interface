//
//  User.swift
//  Vk_Koloshenko
//
//  Created by Timofey Koloshenko on 15/08/2019.
//  Copyright © 2019 Timofey Koloshenko. All rights reserved.
//

import Foundation

class User {
    var name : String
    var image : String
    
    init(name : String, image : String) {
        self.name = name
        self.image = image
    }
}
