//
//  LoginScreenReturnController.swift
//  Vk_Koloshenko
//
//  Created by Timofey Koloshenko on 12/08/2019.
//  Copyright © 2019 Timofey Koloshenko. All rights reserved.
//

import UIKit

class LoginScreenReturnController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func returnButtonPressed(_ sender: Any) {
        // if you use navigation controller, just pop ViewController:
        if let nvc = navigationController {
            nvc.popViewController(animated: true)
        } else {
            // otherwise, dismiss it
            dismiss(animated: true, completion: nil)
        }
    }
}
