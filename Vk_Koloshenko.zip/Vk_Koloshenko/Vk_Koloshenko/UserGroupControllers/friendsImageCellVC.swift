//
//  friendsImageCellVC.swift
//  Vk_Koloshenko
//
//  Created by Timofey Koloshenko on 16/08/2019.
//  Copyright © 2019 Timofey Koloshenko. All rights reserved.
//

import UIKit

class friendsImageCellVC: UICollectionViewCell {
    @IBOutlet weak var cellImageView: UIImageView!
    
    func setImageViaName(imageName : String) {
        self.cellImageView.image = UIImage(named: imageName)
    }
    
    func setImage(image : UIImage)
    {
        self.cellImageView.image = image
    }
}
